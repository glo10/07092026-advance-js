var currentUser = "Alice";
var status = "online";

function renderHeader() {
  console.log("Utilisateur connecté : " + currentUser + " (" + status + ")");
}