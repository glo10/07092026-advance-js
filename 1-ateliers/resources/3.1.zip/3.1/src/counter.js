var count = 0;

function increment() {
  count++;
}

function getCount() {
  return count;
}