var status = "pending_payment";
var total = 150;

function processOrder() {
  if (status === "pending_payment") {
    console.log("Traitement de la commande de " + total + "€...");
  }
}