console.log("App initialisée");
var titleText = document.getElementById("title").innerText; // Crashe ici !