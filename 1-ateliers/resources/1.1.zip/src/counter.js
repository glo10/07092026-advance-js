export class Counter {
  constructor() {
    this.count = 0;
  }

  start() {
    setTimeout(function(){
      this.count++;
      console.log(`Compteur : ${this.count}`);
    }, 1000);
  }
}