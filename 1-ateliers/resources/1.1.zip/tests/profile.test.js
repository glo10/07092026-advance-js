import { describe, test, expect } from "vitest";
import {
  profile,
} from "../src/profile";

describe("Testing profile", () => {
  test("Doit retourner le résumé du profil", () => {
    const result; // TODO
    expect(result).toBe(
      "Alice est Développeuse JS/TS."
    );
  });

  test("Doit utiliser correctement this.name et this.role", () => {
    // TODO
    expect(profile.getSummary()).toBe(
      "Marc est Designer."
    );

    // Nettoyage pour éviter d'impacter les autres tests
    profile.name = "Alice";
    profile.role = "Développeuse JS/TS";
  });
});