import { describe, it, expect } from "vitest";
import {
  devLogger,
} from "../src/dev-logger";

describe("devLogger", () => {
  it("Doit générer correctement le message de log", () => {
    const result = devLogger.log(
      "info",
      "Utilisateur connecté",
      "2026-09-07 11:00:00"
    );

    expect(result).toBe(
      "[SaaS-App] [INFO] (2026-09-07 11:00:00) : Utilisateur connecté"
    );
  });

  it("Doit convertir le niveau en majuscules", () => {
    const result; // TODO

    expect(result).toContain("[ERROR]");
  });

  it("Doit utiliser correctement this.appName", () => {
    devLogger.appName = "My-App";

    const result; // TODO

    expect(result).toBe(
      "[My-App] [DEBUG] (11:00:00) : Test"
    );

    // Nettoyage
    devLogger.appName = "SaaS-App";
  });
});