function fetchUserData(userId) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (userId % 2 === 0) {
        resolve({ id: userId, isIdEven : true});
      } else {
        reject(new Error(`${userId} is odd`));
      }
    }, 500);
  });
}