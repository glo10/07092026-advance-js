var defaultSettings = {
  theme: "dark",
  notifications: true,
  sidebar: false,
  timezone: 'UTC'
};

var userSettings = {
  sidebar: true,
  language: "fr",
  timezone: 'Europe/Paris'
};